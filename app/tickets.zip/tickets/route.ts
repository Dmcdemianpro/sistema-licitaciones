import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const tickets = await prisma.ticket.findMany({ orderBy: { createdAt: "desc" } });
  return NextResponse.json(tickets);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const ticket = await prisma.ticket.create({
    data: {
      title: body.title,
      description: body.description,
      extra: body.extra ?? {},
      status: "OPEN",
    },
  });
  return NextResponse.json(ticket, { status: 201 });
}
